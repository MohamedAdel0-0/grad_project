import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:p2papp/screens/home.dart';
import 'dart:io';
import 'package:path/path.dart';

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  File _image;

  @override
  Widget build(BuildContext context) {

//    Future getImage() async {
//      var image = await ImagePicker.pickImage(source: ImageSource.gallery);
//
//      setState(() {
//        _image = image;
//        print('Image Path $_image');
//      });
//    }

//    Future uploadPic(BuildContext context) async{
//      String fileName = basename(_image.path);
//      StorageReference firebaseStorageRef = FirebaseStorage.instance.ref().child(fileName);
//      StorageUploadTask uploadTask = firebaseStorageRef.putFile(_image);
//      StorageTaskSnapshot taskSnapshot=await uploadTask.onComplete;
//      setState(() {
//        print("Profile Picture uploaded");
//        Scaffold.of(context).showSnackBar(SnackBar(content: Text('Profile Picture Uploaded')));
//      });
//    }

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context);
            }),
        title: Text('Edit Profile',textAlign: TextAlign.left,),
      ),
      body: Builder(
        builder: (context) =>  Container(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              SizedBox(
                height: 25.0,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[

                   CircleAvatar(
                        radius: 70,
                        backgroundColor: Colors.blueAccent,
                        child: ClipOval(
                          child: new SizedBox(
                            width: 120.0,
                            height: 120.0,
                            child: (_image!=null)?Image.file(
                              _image,
                              fit: BoxFit.fill,
                            ):Image.network(
                              "https://images.unsplash.com/photo-1502164980785-f8aa41d53611?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
                              fit: BoxFit.fill,
                            ),
                          ),
                        ),
                      ),


                  Padding(
                    padding: EdgeInsets.only(top: 90.0,),
                    child: IconButton(
                        icon: Icon(Icons.add_a_photo,
                          size: 30.0,
                          color: Colors.blueGrey,
                        ),
                        onPressed: () {
                          //getImage();
                        },
                      ),
                  ),

                ],
              ),
              SizedBox(
                height: 20.0,
              ),
              Row(
               // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  Align(

                    child: Container(
                      child: Column(
                        children: <Widget>[
                           Container(
                             margin: EdgeInsets.only(right: 45,bottom: 10),
                             child: Text('Username',
                                  style: TextStyle(
                                      color: Colors.blueGrey, fontSize: 18.0),),
                           ),
                           Container(
                               margin: EdgeInsets.only(left: 55),
                               child: Text('------------------',
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 20.0,
                                      fontWeight: FontWeight.bold),),
                           ),

                        ],
                      ),
                    ),
                  ),
                           Container(
                             margin: EdgeInsets.only(left: 100),
                               child: Icon(Icons.edit,
                                color: Color(0xff476cfb),
                             ),
                           ),

                ],
              ),
              SizedBox(
                height: 20.0,
              ),
              Row(
                // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  Align(
                    child: Container(
                      child: Column(
                        children: <Widget>[
                          Container(
                            margin: EdgeInsets.only(right: 75,bottom: 10),
                            child: Text('Phone',
                              style: TextStyle(
                                  color: Colors.blueGrey, fontSize: 18.0),),
                          ),
                          Container(
                            margin: EdgeInsets.only(left: 55),
                            child: Text('------------------',
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 20.0,
                                  fontWeight: FontWeight.bold),),
                          ),

                        ],
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 100),
                    child: Icon(Icons.edit,
                      color: Color(0xff476cfb),
                    ),
                  ),

                ],
              ),
              SizedBox(
                height: 10.0,
              ),
              Row(
                // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  Align(

                    child: Container(
                      child: Column(
                        children: <Widget>[
                          Container(
                            margin: EdgeInsets.only(left: 32,bottom: 10),
                            child: Text('Registration Number',
                              style: TextStyle(
                                  color: Colors.blueGrey, fontSize: 18.0),),
                          ),
                          Container(
                            margin: EdgeInsets.only(left: 55),
                            child: Text('------------------',
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 20.0,
                                  fontWeight: FontWeight.bold),),
                          ),

                        ],
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 100),
                    child: Icon(Icons.edit,
                      color: Color(0xff476cfb),
                    ),
                  ),

                ],
              ),
              Container(
                margin: EdgeInsets.only(left: 32,top: 15,bottom: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Text('Email',
                        style:
                        TextStyle(color: Colors.blueGrey, fontSize: 18.0)),
                    SizedBox(width: 20.0),
                    Text('student@aast.edu.com',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 20.0,
                            fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
              Row(
                // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  Align(

                    child: Container(
                      child: Column(
                        children: <Widget>[
                          Container(
                            margin: EdgeInsets.only(right: 45,bottom: 10),
                            child: Text('Password',
                              style: TextStyle(
                                  color: Colors.blueGrey, fontSize: 18.0),),
                          ),
                          Container(
                            margin: EdgeInsets.only(left: 55),
                            child: Text('***************',
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 20.0,
                                  fontWeight: FontWeight.bold),),
                          ),

                        ],
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 100),
                    child: Icon(Icons.edit,
                      color: Color(0xff476cfb),
                    ),
                  ),

                ],
              ),
              SizedBox(
                height: 20.0,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[

                  Container(
                    width: 200,
                    child: RaisedButton(
                      color: Color(0xff476cfb),
                      onPressed: () {
                       // uploadPic(context);
                        Navigator.push(context, MaterialPageRoute(builder: (context){
                          return home();
                        }));
                      },
                      elevation: 4.0,
                      splashColor: Colors.blueGrey,
                      child: Text(
                        'Submit',
                        style: TextStyle(color: Colors.white, fontSize: 18.0),
                      ),
                    ),
                  ),

                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}