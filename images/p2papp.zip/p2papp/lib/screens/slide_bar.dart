import 'dart:async';
import 'package:flutter/material.dart';
import 'package:p2papp/screens/welcome.dart';
import 'package:p2papp/screens/log_in.dart';
import 'sideBarItem.dart';
import 'package:rxdart/rxdart.dart';


class slide_bar extends StatefulWidget{
    @override
    _slidebarState createState() => _slidebarState();
}

class _slidebarState extends State<slide_bar> with SingleTickerProviderStateMixin <slide_bar>{
    AnimationController _animationController;
    StreamController <bool> issidebaropenedstreamcontroller;
    Stream <bool> issidebaropenstream ;
    StreamSink <bool> issidebaropensink ;
    final _animationDuration = const Duration(microseconds: 500);
    final  bool isopened = true ;

    @override
    void initState() {
      super.initState();
      _animationController = AnimationController(vsync: this , duration: _animationDuration);
      issidebaropenedstreamcontroller = PublishSubject <bool>();
      issidebaropenstream = issidebaropenedstreamcontroller.stream;
      issidebaropensink = issidebaropenedstreamcontroller.sink;
    }

  @override
  void dispose() {
    _animationController.dispose();
    issidebaropenedstreamcontroller.close();
    issidebaropensink.close();
    super.dispose();
  }

  void oniconpressed(){
      final animationstate = _animationController.status ;
      final isanimationcomplete = animationstate == AnimationStatus.completed ;
      if(isanimationcomplete){
        issidebaropensink.add(false);
        _animationController.reverse();
      }
      else{
        issidebaropensink.add(true);
        _animationController.forward();
      }
  }

  @override
  Widget build(BuildContext context) {
    final screenwidth = MediaQuery.of(context).size.width ;

    return StreamBuilder <bool>(
      initialData: false,
      stream: issidebaropenstream,
      builder: (context , isopened){
        return AnimatedPositioned(
          duration: _animationDuration,
          top: 0,
          bottom: 0,
          left: isopened.data ? 0 : -screenwidth,
          right: isopened.data ? 0 : screenwidth - 32,

          child: Row(
            children: <Widget>[

              Expanded(
                child: Container(

                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                        colors: [
                          Colors.blue[900],
                          Colors.blue[600],
                          Colors.blue[400],
                          Colors.blue[600],
                          Colors.blue[900],
                        ],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter
                    ),
                  ),

                  child: Column(
                    children: <Widget>[

                      SizedBox(height: 100,),

                      ListTile(
                        title: Text(
                          "Name",
                          style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w800),
                        ),
                        subtitle: Text(
                          "email.student.edu",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                          ),
                        ),
                        leading: CircleAvatar(
                          child: Icon(
                            Icons.perm_identity,
                            color: Colors.white,
                          ),
                          radius: 50,
                          backgroundColor: Colors.blue[900],
                        ),
                      ),

                      Divider(
                        height: 64,
                        thickness: 0.5,
                        color: Colors.white.withOpacity(0.3),
                        indent: 32,
                        endIndent: 32,
                      ),

                      MenuItem(
                        icon: Icons.group,
                        title: "My Groups",
                        onTap: () {
                          //oniconpressed();
                          //BlocProvider.of<NavigationBloc>(context).add(NavigationEvents.MyAccountClickedEvent);
                        },
                      ),

                      MenuItem(
                        icon: Icons.assignment,
                        title: "My Gaps",
                        onTap: () {
                          //oniconpressed();
                         // BlocProvider.of<NavigationBloc>(context).add(NavigationEvents.MyOrdersClickedEvent);
                        },
                      ),

                      MenuItem(
                        icon: Icons.card_giftcard,
                        title: "My Material",
                        onTap: () {
                          //oniconpressed();
                          // BlocProvider.of<NavigationBloc>(context).add(NavigationEvents.MyOrdersClickedEvent);
                        },
                      ),
                      Divider(
                        height: 64,
                        thickness: 0.5,
                        color: Colors.white.withOpacity(0.3),
                        indent: 32,
                        endIndent: 32,
                      ),
//                      MenuItem(
//                        icon: Icons.settings,
//                        title: "Settings",
//                      ),
                      MenuItem(
                        icon: Icons.exit_to_app,
                        title: "Logout",
                        onTap: () {
                          //oniconpressed();
                          Navigator.of(context).pop(true);
                        },
                      ),

                    ],
                  ),

                ),
              ),
              Align(
                alignment: Alignment(0, -0.9999),
                child: GestureDetector(
                  onTap: (){
                      oniconpressed();
                       },
                  child: ClipPath(
                      clipper : CustomMenuClipper(),
                    child: Container(
                      width: 35,
                      height: 100,
                      //color :Color(0xFF2881D0),
                      color: Colors.blue[700],
                      alignment: Alignment.center,
                      child: AnimatedIcon(
                        icon: AnimatedIcons.menu_close,
                        progress: _animationController.view,
                        color: Colors.white,
                        size: 30,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class CustomMenuClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Paint paint = Paint();
    paint.color = Colors.blue[700];

    final width = size.width;
    final height = size.height;

    Path path = Path();
    path.moveTo(0, 0);
    path.quadraticBezierTo(0, 6, 10, 14);
    path.quadraticBezierTo(width - 1, height / 2 - 20, width, height / 2);
    path.quadraticBezierTo(width + 1, height / 2 + 20, 8, height - 14);
    path.quadraticBezierTo(0, height - 6, 0, height);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    return true;
  }

}